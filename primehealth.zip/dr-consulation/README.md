# Telemedicine project
This is a simple telemedicine project which helps doctor and patients to connect using video conferencing and chat. You can see the full demo of the same at https://www.youtube.com/watch?v=GslXbdrWbgk. The video is in Nepalese language but you should be able to follow it up.

Below  is the basic flow of the project.

1. Doctor logs in , Patient logs in by filling his issues.
2. Both go in to video conference call and discuss issues.
3. Doctor fills advice.
4. Patient can  print advice after the call.
5. Doctor and patients can also send chat messages to each other. 
6. Patients can also share documents with doctor.



Features :-

Application supports Multi doctor and Multihospital.

Medication can be filled by Doc

Patient can input problems

Chat message support between doctors and patients.

Patients can share document with doctors while conferencing.

Tracks time spent per call between doctor and patient.

Its created using Angular as front end and .NET core as back end and postgre database. Any further technical clarification send me mail at shiv_koirala@yahoo.com.

This complete initative is funded by https://danphehealth.com . 
--