import {Component} from '@angular/core' 

@Component({
    template:'<h3> <strong>404<strong> Page not found, Kindly check your URL<h3>',
})
export class PageNotFound{

}