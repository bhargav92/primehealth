export class SMSModel {
    message: string = "";
    mobileNo: string = "";
}