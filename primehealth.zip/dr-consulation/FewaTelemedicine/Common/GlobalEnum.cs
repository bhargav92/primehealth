﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FewaTelemedicine.Common
{
    public enum TeleConstants
    {
        PatientCalled = 1,
        PatientWaitingRoom = 0,
        PatientCompleted = -1,
    }
}
