﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FewaTelemedicine.Domain.Models
{
    public class SMSModel
    {
        public string MobileNo { get; set; }
        public string Message { get; set; }
    }
}
